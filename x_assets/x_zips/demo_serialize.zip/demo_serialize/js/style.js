function center() {
	$('.gridster').scrollTo( '50%', {axis: 'x'} );
	// $('body.record').scrollTo( '50%', {axis: 'xy'} );
};

$(document).ready(center); // When the page first loads
$(window).resize(center); // When the browser changes size */